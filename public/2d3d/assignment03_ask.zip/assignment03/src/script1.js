let dummy = function(){
    console.log('hello world')
}




export default dummy;